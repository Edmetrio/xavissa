

<?php $__env->startSection('content'); ?>
<div class="content-wrap">
    <div class="page-title">
        <h1>Adicionar</h1>
        <p>Área específica para Adicionar</p>
    </div>
    <div class="content-inner remove-ext5">
        <div class="row mrg20">
            <div class="col-md-12 col-sm-12 col-lg-12">
                <div class="wdgt-box chckut-wrp">
                        <div class="chckut-innr">
                            <div class="wdgt-titl">
                                <h4>Categoria</h4>
                                <p>Por favor, preencha todos campos</p>
                            </div>
                            <div class="chckut-inr">
                                <form action="<?php echo e(url('categoria')); ?>" method="POST" enctype="multipart/form-data">
                                    <?php echo csrf_field(); ?>
                                    <div class="row mrg20">
                                        <div class="col-md-6 col-sm-12 col-lg-6">
                                            <input type="text" name="nome" placeholder="Nome da Categoria*">
                                        </div>
                                        <div class="col-md-6 col-sm-12 col-lg-6">
                                            <input type="file" name="image" id="image" placeholder="prata.jpg*">
                                        </div>
                                        <button type="submit" value="">Submeter</button>
                                    </div><br>
                                </form>

                               <!--  <div class="invoc-dta">
                                    <table>
                                        <thead>
                                            <tr>
                                                <th>Nome da Categoria</th>
                                                <th>Icon</th>
                                                <th>Visibilidade</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = $categoria; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><span><?php echo e($c->nome); ?></span></td>
                                                <td><?php echo e($c->icon); ?></td>
                                                <td><span><?php echo e($c->visivel); ?></span></td>
                                            </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                    <div class="invoc-tl">
                                        <span>Total:<i><?php echo e($numero); ?></i></span>
                                    </div>
                                </div> -->
                            </div>
                        </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\xavisa\resources\views/createCategoria.blade.php ENDPATH**/ ?>