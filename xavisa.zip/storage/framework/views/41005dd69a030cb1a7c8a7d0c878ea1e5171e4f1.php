

<?php $__env->startSection('content'); ?>
<div class="content-wrap">
    <div class="page-title">
        <h1>Adicionar</h1>
        <p>Área específica para Adicionar</p>
    </div>
    <div class="content-inner remove-ext5">
        <div class="row mrg20">
            <div class="col-md-12 col-sm-12 col-lg-12">
                <div class="wdgt-box chckut-wrp">
                    <div class="chckut-innr">
                        <div class="wdgt-titl">
                            <h4>Categoria</h4>
                            <p>Por favor, preencha todos campos</p>
                        </div>
                        <div class="chckut-inr">
                            <form action="<?php echo e(url('venda')); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <div class="row mrg20">
                                    <div class="col-md-6 col-sm-12 col-lg-6">
                                        <select name="categoria_id">
                                            <?php $__currentLoopData = $categoria; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($c->id); ?>"><?php echo e($c->nome); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                    <div class="col-md-6 col-sm-12 col-lg-6">
                                        <select name="produto_id">
                                            <?php $__currentLoopData = $produto; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($p->id); ?>"><?php echo e($p->nome); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                    <div class="col-md-6 col-sm-12 col-lg-6">
                                        <input type="numeric" name="quantidade" placeholder="Quantidade*">
                                    </div>
                                    <div>
                                        <button type="submit" value="">Adicionar</button>
                                    </div>
                                </div>
                            </form>

                            <!--  <div class="invoc-dta">
                                    <table>
                                        <thead>
                                            <tr>
                                                <th>Nome da Categoria</th>
                                                <th>Icon</th>
                                                <th>Visibilidade</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            
                                            <tr>
                                                
                                            </tr>
                                           
                                        </tbody>
                                    </table>
                                    <div class="invoc-tl">
                                        <span>Total:<i></i></span>
                                    </div>
                                </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\xavisa\resources\views/createVenda.blade.php ENDPATH**/ ?>