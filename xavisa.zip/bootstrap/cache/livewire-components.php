<?php return array (
  'venda' => 'App\\Http\\Livewire\\Venda',
);