

<?php $__env->startSection('content'); ?>
<div class="content-wrap">
    <div class="page-title">
        <h1>Categorias e Produtos</h1>
        <p>Todas Categorias e Produtos</p>
    </div>
    <div class="content-inner remove-ext5">
        <div class="row mrg20">
            <div class="col-md-12 col-sm-12 col-lg-12">
                <div class="wdgt-box prd-wrp">
                    <div class="wdgt-titl">
                        <h4>Categoria</h4>
                        <p>Todas Categorias da sua Loja você encontra aqui</p>
                    </div>
                    <div class="remove-ext3">
                        <div class="row">
                            <?php $__currentLoopData = $categoria; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-md-4 col-sm-6 col-lg-4">
                                <div class="prd-box">
                                    <div class="prd-thmb">
                                        <!-- <div class="col-md-6 col-sm-12 col-lg-6">
                                                <span class="prd-prc">Visibilidade</span>
                                            </div> -->
                                        <img src="<?php echo e(asset('assets/images/slider/'.$c->icon)); ?>" alt="prd-img1-1.jpg">
                                        <div class="prd-btns">
                                            <a class="prd-wshlst-btn" href="<?php echo e(url('categoria/'.$c->id.'/edit')); ?>" title="Alterar"><i class="fa fa-pencil edit-btn"></i></a>
                                            <a class="prd-adcrt-btn" href="<?php echo e(url('cdestroy/'.$c->id)); ?>" title="Apagar"><i class="fa fa-trash-o"></i></a>
                                        </div>
                                    </div>
                                    <div class="prd-inf">
                                        <?php if($c->visivel == ''): ?><span class="ratng"><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i></span>
                                        <?php elseif($c->visivel == 1): ?><span class="ratng"><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i></span>
                                        <?php elseif($c->visivel == 'on'): ?><span class="prd-prc">Visível</span><?php endif; ?>
                                        <h4><a href="<?php echo e(url('categoria/'.$c->id.'/edit')); ?>" title=""><?php echo e($c->nome); ?></a></h4>
                                        <div class="opt-btn">
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>
                <div class="wdgt-box prd-wrp">
                    <div class="wdgt-titl">
                        <h4>Produtos</h4>
                        <p>Todos produtos na sua Loja</p>
                    </div>
                    <div class="remove-ext3">
                        <div class="row">
                            <?php $__currentLoopData = $produto; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-md-4 col-sm-6 col-lg-4">
                                <div class="prd-box text-center">
                                    <div class="prd-thmb">
                                        <img src="<?php echo e(asset('assets/images/product/'.$p->icon)); ?>" alt="prd-img2-1.jpg">
                                        <div class="prd-btns">
                                            <a class="prd-wshlst-btn" href="<?php echo e(url('produto/'.$p->id.'/edit')); ?>" title="Alterar"><i class="fa fa-pencil edit-btn"></i></a>
                                            <a class="prd-adcrt-btn" href="<?php echo e(url('pdestroy/'.$p->id)); ?>" title="Apagar"><i class="fa fa-trash-o"></i></a>
                                        </div>
                                    </div>
                                    <div class="prd-inf">
                                    <?php if($p->visivel == ''): ?><span class="ratng"><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i></span>
                                        <?php elseif($p->visivel == 1): ?><span class="ratng"><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i></span>
                                        <?php elseif($p->visivel == 'on'): ?><span class="prd-prc">Visível</span><?php endif; ?>
                                        <h4><a href="<?php echo e(url('produto/'.$p->id.'/edit')); ?>" title=""><?php echo e($p->nome); ?></a></h4>
                                        <span class="prd-prc">$ <?php echo e($p->preco); ?>,00</span>
                                    </div>
                                </div>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\xavisa\resources\views/base.blade.php ENDPATH**/ ?>