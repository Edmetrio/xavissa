

<?php $__env->startSection('content'); ?>
<div class="content-wrap">
    <div class="page-title">
        <h1>Estoque</h1>
        <p>Área específica para <?php if(isset($pagar)): ?> Alterar <?php else: ?> Adicionar <?php endif; ?></p>
    </div>
    <div class="content-inner remove-ext5">
        <div class="row mrg20">
            <div class="col-md-12 col-sm-12 col-lg-12">
                <div class="wdgt-box chckut-wrp">
                    <div class="chckut-innr">
                        <div class="wdgt-titl">
                            <h4>Aumento de Estoque</h4>
                            <p>Por favor, preencha todos campos</p>
                            <?php if(session('status')): ?>
                            <div class="alert alert-success" role="alert" style="text-align: center; font-weight: bold;">
                                <p class="status"><?php echo e(session('status')); ?></p>
                            </div>
                            <?php endif; ?>
                        </div>
                        <div class="chckut-inr">
                            <form action="<?php echo e(url('aumentar')); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <div class="row mrg20">
                                    <div class="col-md-6 col-sm-12 col-lg-5">
                                        <select name="produto_id">
                                            <?php $__currentLoopData = $produto; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($p->id); ?>"><?php echo e($p->nome); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                    <input type="text" hidden name="user_id" value="<?php echo e(Auth::user()->id); ?>">

                                    <div class="col-md-6 col-sm-12 col-lg-6">
                                        <!-- <input type="number" name="quantidade" placeholder="Quantidade"> -->
                                        <div class="qt-ad-crt">
                                            <div class="qnty">
                                                <input type="text" name="quantidade" value="1" required>
                                            </div>
                                        <button type="submit" value=""> <?php if(isset($pagar)): ?> Alterar <?php else: ?> Adicionar <?php endif; ?></button>

                                        </div>
                                    </div>
                                </div><br>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\xavisa\resources\views/createEstoqueAumento.blade.php ENDPATH**/ ?>